package com.example.autotranslator

import android.app.Application

class TranslatorApp : Application()
