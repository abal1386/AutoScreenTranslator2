package com.example.autotranslator

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.google.android.gms.tasks.Task
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.concurrent.atomic.AtomicBoolean

class ScreenTranslatorService : Service() {

    companion object {
        const val EXTRA_RESULT_CODE = "extra_result_code"
        const val EXTRA_DATA = "extra_data"
        const val EXTRA_TARGET_LANGUAGE = "extra_target_language"
        private const val CHANNEL_ID = "screen_translator"
        private const val NOTIFICATION_ID = 1001
    }

    private val serviceJob = SupervisorJob()
    private val scope = CoroutineScope(Dispatchers.Default + serviceJob)
    private val processing = AtomicBoolean(false)
    private val mainHandler = Handler(Looper.getMainLooper())

    private lateinit var overlayController: OverlayController

    private var mediaProjection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var translator: Translator? = null
    private var translatorKey: String? = null
    private var currentTargetLanguage: String = TranslateLanguage.PERSIAN

    private val textRecognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    private val languageIdentifier by lazy {
        LanguageIdentification.getClient(
            LanguageIdentificationOptions.Builder()
                .setConfidenceThreshold(0.20f)
                .build()
        )
    }

    override fun onCreate() {
        super.onCreate()
        overlayController = OverlayController(this)
        createNotificationChannel()
        startForegroundSafely(buildForegroundNotification())
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, 0) ?: 0
        val data: Intent? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent?.getParcelableExtra(EXTRA_DATA)
        }
        currentTargetLanguage = intent?.getStringExtra(EXTRA_TARGET_LANGUAGE) ?: TranslateLanguage.PERSIAN
        TranslationStateStore.setTargetLanguage(currentTargetLanguage)

        if (resultCode == 0 || data == null) {
            TranslationStateStore.setStatus("ورودی Screen Capture ناقص است")
            stopSelf()
            return START_NOT_STICKY
        }

        startCapturePipeline(resultCode, data)
        return START_STICKY
    }

    private fun startCapturePipeline(resultCode: Int, data: Intent) {
        scope.launch {
            try {
                val projectionManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                mediaProjection = projectionManager.getMediaProjection(resultCode, data)
                val projection = mediaProjection ?: error("MediaProjection دریافت نشد")

                val metrics = getDisplayMetrics()
                val width = metrics.widthPixels
                val height = metrics.heightPixels
                val densityDpi = metrics.densityDpi

                imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
                imageReader?.setOnImageAvailableListener({ reader ->
                    if (processing.compareAndSet(false, true)) {
                        scope.launch {
                            try {
                                processLatestFrame(reader)
                            } catch (e: Exception) {
                                TranslationStateStore.setStatus("خطا: ${e.message ?: "نامشخص"}")
                            } finally {
                                processing.set(false)
                            }
                        }
                    }
                }, mainHandler)

                virtualDisplay = projection.createVirtualDisplay(
                    "screen-translator",
                    width,
                    height,
                    densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader?.surface,
                    null,
                    mainHandler
                )

                projection.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() {
                        cleanup("ضبط صفحه متوقف شد", true)
                    }
                }, mainHandler)

                mainHandler.post { overlayController.showIfPossible() }
                TranslationStateStore.setRunning(true)
                TranslationStateStore.setStatus("ترجمه‌ی زنده شروع شد")
            } catch (e: Exception) {
                cleanup("خطا در شروع: ${e.message ?: "نامشخص"}", true)
            }
        }
    }

    private suspend fun processLatestFrame(reader: ImageReader) {
        val image = reader.acquireLatestImage() ?: return
        image.use { frame ->
            val bitmap = frame.toBitmap()
            val textResult = textRecognizer.process(InputImage.fromBitmap(bitmap, 0)).await()
            val recognized = textResult.text.trim()

            if (recognized.isBlank()) {
                TranslationStateStore.setStatus("متنی پیدا نشد")
                overlayController.updateText("متنی پیدا نشد")
                return
            }

            val languageTag = languageIdentifier.identifyLanguage(recognized).await()
            val sourceLanguage = TranslateLanguage.fromLanguageTag(languageTag) ?: TranslateLanguage.ENGLISH
            val key = "$sourceLanguage->$currentTargetLanguage"

            if (translator == null || translatorKey != key) {
                translator?.close()
                translator = Translation.getClient(
                    TranslatorOptions.Builder()
                        .setSourceLanguage(sourceLanguage)
                        .setTargetLanguage(currentTargetLanguage)
                        .build()
                )
                translatorKey = key
                translator?.downloadModelIfNeeded()?.await()
            }

            val translated = translator?.translate(recognized)?.await()?.trim().orEmpty()

            TranslationStateStore.setTexts(
                recognized = recognized,
                translated = translated,
                sourceTag = languageTag,
                status = "ترجمه شد"
            )
            overlayController.updateText(translated.ifBlank { recognized })
        }
    }

    private fun cleanup(status: String, stopSelfAfter: Boolean) {
        TranslationStateStore.setStatus(status)
        TranslationStateStore.setRunning(false)
        mainHandler.post { overlayController.hide() }
        processing.set(false)
        imageReader?.setOnImageAvailableListener(null, null)
        imageReader?.close()
        imageReader = null
        virtualDisplay?.release()
        virtualDisplay = null
        mediaProjection?.stop()
        mediaProjection = null
        translator?.close()
        translator = null
        translatorKey = null
        if (stopSelfAfter) {
            stopSelf()
        }
    }

    private fun getDisplayMetrics(): DisplayMetrics {
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(metrics)
        return metrics
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Screen Translator",
                NotificationManager.IMPORTANCE_LOW
            )
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun buildForegroundNotification(): Notification {
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.sym_action_chat)
            .setContentTitle("Auto Screen Translator")
            .setContentText("در حال آماده‌سازی ترجمه‌ی صفحه")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .build()
    }

    private fun startForegroundSafely(notification: Notification) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    override fun onDestroy() {
        cleanup("سرویس متوقف شد", false)
        textRecognizer.close()
        languageIdentifier.close()
        serviceJob.cancel()
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

private fun Image.use(block: (Image) -> Unit) {
    try {
        block(this)
    } finally {
        close()
    }
}
