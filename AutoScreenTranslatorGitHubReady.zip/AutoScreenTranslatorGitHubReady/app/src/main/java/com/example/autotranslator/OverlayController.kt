package com.example.autotranslator

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.WindowManager
import android.os.Handler
import android.os.Looper
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class OverlayController(private val context: Context) {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())
    private var rootView: ScrollView? = null
    private var textView: TextView? = null

    fun showIfPossible() {
        if (rootView != null) return
        if (!android.provider.Settings.canDrawOverlays(context)) {
            TranslationStateStore.setStatus("اجازه‌ی overlay داده نشده، فقط داخل برنامه نمایش داده می‌شود")
            return
        }

        val text = TextView(context).apply {
            setTextColor(android.graphics.Color.WHITE)
            textSize = 16f
            setPadding(32, 32, 32, 32)
            setBackgroundColor(0xCC000000.toInt())
            this.text = "در انتظار ترجمه..."
        }

        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xCC111111.toInt())
            addView(text)
        }

        val scroll = ScrollView(context).apply {
            addView(container)
        }

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            y = 100
        }

        mainHandler.post {
            runCatching { windowManager.addView(scroll, params) }
            rootView = scroll
            textView = text
        }
    }

    fun updateText(text: String) {
        textView?.post {
            textView?.text = text
        }
    }

    fun hide() {
        val view = rootView
        mainHandler.post {
            if (view != null) {
                runCatching { windowManager.removeView(view) }
            }
            rootView = null
            textView = null
        }
    }
}
