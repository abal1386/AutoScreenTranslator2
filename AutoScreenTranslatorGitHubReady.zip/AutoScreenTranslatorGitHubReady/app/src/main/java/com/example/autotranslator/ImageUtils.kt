package com.example.autotranslator

import android.graphics.Bitmap
import android.media.Image
import java.nio.ByteBuffer

fun Image.toBitmap(): Bitmap {
    val plane = planes[0]
    val buffer: ByteBuffer = plane.buffer
    buffer.rewind()

    val pixelStride = plane.pixelStride
    val rowStride = plane.rowStride
    val rowPadding = rowStride - pixelStride * width

    val bitmap = Bitmap.createBitmap(
        width + rowPadding / pixelStride,
        height,
        Bitmap.Config.ARGB_8888
    )
    bitmap.copyPixelsFromBuffer(buffer)
    return Bitmap.createBitmap(bitmap, 0, 0, width, height)
}
