package com.example.autotranslator

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.Lifecycle
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private val languages = listOf(
        "fa" to "فارسی",
        "en" to "English",
        "ar" to "العربية",
        "tr" to "Türkçe",
        "ru" to "Русский",
        "de" to "Deutsch",
        "fr" to "Français",
        "es" to "Español"
    )

    private val requestNotificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { }

    private val overlayPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            TranslationStateStore.setStatus("اجازه‌ی نمایش روی صفحه بررسی شد")
        }

    private val screenCaptureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode != RESULT_OK || result.data == null) {
                TranslationStateStore.setStatus("اجازه‌ی ضبط صفحه داده نشد")
                return@registerForActivityResult
            }

            val serviceIntent = Intent(this, ScreenTranslatorService::class.java).apply {
                putExtra(ScreenTranslatorService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenTranslatorService.EXTRA_DATA, result.data)
                putExtra(ScreenTranslatorService.EXTRA_TARGET_LANGUAGE, TranslationStateStore.state.value.targetLanguageTag)
            }

            ContextCompat.startForegroundService(this, serviceIntent)
        }

    private lateinit var languageSpinner: Spinner
    private lateinit var statusText: TextView
    private lateinit var sourceText: TextView
    private lateinit var recognizedText: TextView
    private lateinit var translatedText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        languageSpinner = findViewById(R.id.languageSpinner)
        statusText = findViewById(R.id.statusText)
        sourceText = findViewById(R.id.sourceText)
        recognizedText = findViewById(R.id.recognizedText)
        translatedText = findViewById(R.id.translatedText)

        setupLanguageSpinner()
        setupButtons()
        observeState()
        requestNotificationIfNeeded()
    }

    private fun setupLanguageSpinner() {
        val labels = languages.map { it.second }
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)
        languageSpinner.adapter = adapter
        languageSpinner.setSelection(languages.indexOfFirst { it.first == TranslationStateStore.state.value.targetLanguageTag }.coerceAtLeast(0))
        languageSpinner.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>, view: android.view.View?, position: Int, id: Long) {
                TranslationStateStore.setTargetLanguage(languages[position].first)
            }

            override fun onNothingSelected(parent: android.widget.AdapterView<*>) = Unit
        }
    }

    private fun setupButtons() {
        findViewById<Button>(R.id.startButton).setOnClickListener {
            ensureOverlayPermission()
            startCapture()
        }

        findViewById<Button>(R.id.stopButton).setOnClickListener {
            stopService(Intent(this, ScreenTranslatorService::class.java))
            TranslationStateStore.setRunning(false)
            TranslationStateStore.setStatus("درخواست توقف ارسال شد")
        }
    }

    private fun observeState() {
        lifecycleScope.launch {
            lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
                TranslationStateStore.state.collectLatest { state ->
                    statusText.text = "وضعیت: ${state.status}"
                    sourceText.text = "زبان شناسایی‌شده: ${state.sourceLanguageTag}"
                    recognizedText.text = "متن OCR: ${state.recognizedText.ifBlank { "-" }}"
                    translatedText.text = "ترجمه: ${state.translatedText.ifBlank { "-" }}"
                }
            }
        }
    }

    private fun startCapture() {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as android.media.projection.MediaProjectionManager
        screenCaptureLauncher.launch(mgr.createScreenCaptureIntent())
        TranslationStateStore.setRunning(true)
    }

    private fun ensureOverlayPermission() {
        if (Settings.canDrawOverlays(this)) return
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        overlayPermissionLauncher.launch(intent)
        Toast.makeText(this, "اجازه‌ی نمایش روی صفحه را فعال کن", Toast.LENGTH_SHORT).show()
    }

    private fun requestNotificationIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val granted = ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
            if (!granted) {
                requestNotificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
}
