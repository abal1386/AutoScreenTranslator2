# Auto Screen Translator

پروژه‌ی اندروید برای ترجمه‌ی زنده‌ی صفحه با OCR و ترجمه‌ی روی دستگاه.

## ساخت APK در GitHub
1. این پروژه را در یک Repository در GitHub آپلود کن.
2. فایل `.github/workflows/android.yml` را نگه دار.
3. وقتی روی شاخه `main` push شود، GitHub Actions فایل APK را می‌سازد.
4. از بخش **Actions** فایل `app-debug.apk` را دانلود کن.

## نیازمندی‌ها
- Android 8.0+ (minSdk 26)
- اجازه‌ی Screen Capture
- اجازه‌ی Overlay
- اینترنت برای دانلود مدل‌های ML Kit
