package com.example.autotranslator

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private val screenCaptureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode != RESULT_OK || result.data == null) {
                TranslationStateStore.setStatus("اجازه‌ی ضبط صفحه داده نشد")
                return@registerForActivityResult
            }

            val serviceIntent = Intent(this, ScreenTranslatorService::class.java).apply {
                putExtra(ScreenTranslatorService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(ScreenTranslatorService.EXTRA_DATA, result.data)
                putExtra(ScreenTranslatorService.EXTRA_TARGET_LANGUAGE, TranslationStateStore.state.value.targetLanguageTag)
            }

            ContextCompat.startForegroundService(this, serviceIntent)
        }

    private val overlayPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            TranslationStateStore.setStatus("اجازه‌ی نمایش روی صفحه بررسی شد")
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            val uiState by TranslationStateStore.state.collectAsState()

            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    Column(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(16.dp)
                            .verticalScroll(rememberScrollState()),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Auto Screen Translator",
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold
                        )

                        Text(
                            text = "ترجمه‌ی زنده‌ی صفحه با OCR و ترجمه‌ی روی دستگاه",
                            style = MaterialTheme.typography.bodyMedium
                        )

                        LanguageSelector(
                            current = uiState.targetLanguageTag,
                            onSelected = {
                                TranslationStateStore.setTargetLanguage(it)
                                TranslationStateStore.setStatus("زبان مقصد روی $it تنظیم شد")
                            }
                        )

                        Button(
                            onClick = {
                                ensureOverlayPermission()
                                startCapture()
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("شروع ترجمه")
                        }

                        OutlinedButton(
                            onClick = {
                                stopService(Intent(this@MainActivity, ScreenTranslatorService::class.java))
                                TranslationStateStore.setRunning(false)
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("توقف")
                        }

                        ElevatedCard(modifier = Modifier.fillMaxWidth()) {
                            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("وضعیت: ${uiState.status}")
                                Text("زبان مقصد: ${uiState.targetLanguageTag}")
                                Text("زبان شناسایی‌شده: ${uiState.sourceLanguageTag}")
                                Text("متن OCR:")
                                Text(uiState.recognizedText.ifBlank { "هنوز متنی تشخیص داده نشده" })
                                Divider()
                                Text("ترجمه:")
                                Text(uiState.translatedText.ifBlank { "ترجمه هنوز آماده نیست" })
                            }
                        }

                        Text(
                            text = "نکته: این نسخه از MediaProjection برای گرفتن صفحه، ML Kit برای OCR و ترجمه‌ی آفلاین استفاده می‌کند.",
                            style = MaterialTheme.typography.bodySmall
                        )
                    }
                }
            }
        }
    }

    private fun startCapture() {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as android.media.projection.MediaProjectionManager
        val intent = mgr.createScreenCaptureIntent()
        screenCaptureLauncher.launch(intent)
        TranslationStateStore.setRunning(true)
    }

    private fun ensureOverlayPermission() {
        if (Settings.canDrawOverlays(this)) return
        val intent = Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            Uri.parse("package:$packageName")
        )
        overlayPermissionLauncher.launch(intent)
        Toast.makeText(this, "اجازه‌ی نمایش روی صفحه را فعال کن", Toast.LENGTH_SHORT).show()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun LanguageSelector(
    current: String,
    onSelected: (String) -> Unit
) {
    val options = remember {
        listOf(
            "fa" to "فارسی",
            "en" to "English",
            "ar" to "العربية",
            "tr" to "Türkçe",
            "ru" to "Русский",
            "de" to "Deutsch",
            "fr" to "Français",
            "es" to "Español"
        )
    }

    var expanded by remember { mutableStateOf(false) }
    val label = options.firstOrNull { it.first == current }?.second ?: current

    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = { expanded = !expanded }
    ) {
        OutlinedTextField(
            value = label,
            onValueChange = {},
            readOnly = true,
            label = { Text("زبان مقصد") },
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier.menuAnchor().fillMaxWidth()
        )

        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { expanded = false }
        ) {
            options.forEach { (tag, name) ->
                DropdownMenuItem(
                    text = { Text(name) },
                    onClick = {
                        expanded = false
                        onSelected(tag)
                    }
                )
            }
        }
    }
}
