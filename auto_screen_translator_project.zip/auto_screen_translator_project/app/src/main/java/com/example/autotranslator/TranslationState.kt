package com.example.autotranslator

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class TranslationUiState(
    val running: Boolean = false,
    val targetLanguageTag: String = "fa",
    val sourceLanguageTag: String = "auto",
    val recognizedText: String = "",
    val translatedText: String = "",
    val status: String = "آماده",
)

object TranslationStateStore {
    private val _state = MutableStateFlow(TranslationUiState())
    val state: StateFlow<TranslationUiState> = _state.asStateFlow()

    fun update(transform: (TranslationUiState) -> TranslationUiState) {
        _state.value = transform(_state.value)
    }

    fun setRunning(running: Boolean) {
        update { it.copy(running = running, status = if (running) "در حال اجرا" else "متوقف شد") }
    }

    fun setTargetLanguage(tag: String) {
        update { it.copy(targetLanguageTag = tag) }
    }

    fun setTexts(recognized: String, translated: String, sourceTag: String, status: String = "به‌روزرسانی شد") {
        update {
            it.copy(
                recognizedText = recognized,
                translatedText = translated,
                sourceLanguageTag = sourceTag,
                status = status
            )
        }
    }

    fun setStatus(status: String) {
        update { it.copy(status = status) }
    }
}
