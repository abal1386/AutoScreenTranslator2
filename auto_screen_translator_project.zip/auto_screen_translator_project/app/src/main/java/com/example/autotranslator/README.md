# Auto Screen Translator

این پروژه یک اسکلت عملی برای ترجمه‌ی خودکار و پیوسته‌ی صفحه در اندروید است.

## کارهایی که انجام می‌دهد
- گرفتن تصویر صفحه با MediaProjection و اجازه‌ی کاربر
- OCR متن با ML Kit Text Recognition
- تشخیص زبان متن با ML Kit Language ID
- ترجمه‌ی متن با ML Kit Translation
- نمایش ترجمه در overlay شناور، اگر اجازه داده شود

## ساخت APK
1. پروژه را در Android Studio باز کن.
2. Sync Gradle را بزن.
3. اگر نسخه‌های Gradle یا Compose روی سیستم تو خطا دادند، فقط همان نسخه‌ها را به‌روز کن.
4. روی Run بزن یا از Build > Build Bundle(s) / APK(s) خروجی بگیر.

## مجوزها
- Screen capture consent
- Overlay permission
- Foreground service permission
- Notification permission در Android 13+
